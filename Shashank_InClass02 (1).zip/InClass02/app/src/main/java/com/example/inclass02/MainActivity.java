package com.example.inclass02;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

/*
 * Shashank Mondrati
 * Student ID: 801026182
 * E-Mail: smondrat@uncc.edu
 */
public class MainActivity extends AppCompatActivity {
    // variables to use in this file
    TextView discountPrice;
    EditText userPrice;
    Button calcBtn, clearBtn;
    RadioButton fiveP, tenP, fifteenP, twntyP, fiftyP;
    double discount;
    static int ticketPrice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //user and final results
        discountPrice = findViewById(R.id.discountResult);

        //buttons
        calcBtn = findViewById(R.id.calculateBtn);
        clearBtn = findViewById(R.id.clearBtn);
        //radio buttons
        fiveP = findViewById(R.id.fivePer);
        tenP = findViewById(R.id.tenPer);
        fifteenP = findViewById(R.id.fifteenPer);
        twntyP = findViewById(R.id.twntyPer);
        fiftyP = findViewById(R.id.fiftyPer);
        //userPrice - (userPrice*discount rate): Formula to calculate discount

        calcBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                userPrice = (EditText) findViewById(R.id.enterTicketPrice);
                if(TextUtils.isEmpty(userPrice.getText().toString())){
                    Toast.makeText(getApplicationContext(), "Enter a Number: ", Toast.LENGTH_SHORT).show();
                    return;
                }
                ticketPrice = Integer.parseInt(userPrice.getText().toString());
                //if text box is empty print a toast
                //clicking on buttons
                if (fiveP.isChecked()) { // 5%
                    //discount = 0;
                    discount = ticketPrice - (ticketPrice * 0.05);
                } else if (tenP.isChecked()) { // 10%
                    //discount = 0;
                    discount = ticketPrice - (ticketPrice * 0.10);
                } else if (fifteenP.isChecked()) { // 15%
                    // discount = 0;
                    discount = ticketPrice - (ticketPrice * 0.15);
                } else if (twntyP.isChecked()) { // 20%
                    //discount = 0;
                    discount = ticketPrice - (ticketPrice * 0.20);
                } else if (fiftyP.isChecked()) { // 50%
                    // discount = 0;
                    discount = ticketPrice - (ticketPrice * 0.50);
                }
                discountPrice.setText("Discounted Price: " + discount);
            }

        });
        clearBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                userPrice.setText("");
                discountPrice.setText("Discount Price:");
                Toast.makeText(getApplicationContext(), "Cleared", Toast.LENGTH_SHORT).show();

            }
        });


    }
}