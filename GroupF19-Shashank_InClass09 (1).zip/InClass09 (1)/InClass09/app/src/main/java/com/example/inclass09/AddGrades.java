package com.example.inclass09;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AddGrades extends AppCompatActivity {
    Button submit, cancel;
    EditText courseNum, courseName, courseHours;
    private GradesDatabaseHelper gradesDatabaseHelper;
    private double selectedPoints = 0;
    private double A = 4.0;
    private double B = 3.0;
    private double C = 2.0;
    private double D = 1.0;
    private double F = 0.0;
    RadioGroup gradeRadioGroup;
    RadioButton radioButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_grades);
        submit = (Button) findViewById(R.id.submitBtn);
        cancel = (Button) findViewById(R.id.cancelBtn);

        this.setTitle("Add Grades");
        courseNum = (EditText) findViewById(R.id.courseNumberEdit);
        courseName = (EditText) findViewById(R.id.courseName);
        courseHours = (EditText) findViewById(R.id.courseCreditHours);
        gradeRadioGroup = (RadioGroup) findViewById(R.id.gradeRadioGroup);
        gradeRadioGroup.check(R.id.gradeA);
        radioButton = (RadioButton)findViewById(R.id.gradeA);
        selectedPoints = A;
        gradesDatabaseHelper = new GradesDatabaseHelper(this);

        gradeRadioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                int checkedRadioButtonId = radioGroup.getCheckedRadioButtonId();
                radioButton = (RadioButton)radioGroup.findViewById(checkedRadioButtonId);
                switch (checkedRadioButtonId) {
                    case R.id.gradeA:
                        selectedPoints = A;
                        break;
                    case R.id.gradeB:
                        selectedPoints = B;
                        break;
                    case R.id.gradeC:
                        selectedPoints = C;
                        break;
                    case R.id.gradeD:
                        selectedPoints = D;
                        break;
                    case R.id.gradeF:
                        selectedPoints = F;
                        break;
                }
            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                goToMainScreen();
                Toast.makeText(getApplicationContext(), "Going back to Main Screen", Toast.LENGTH_SHORT).show();
            }
        });

        submit.setOnClickListener(view -> {
            if (TextUtils.isEmpty(courseNum.getText().toString())) {
                Toast.makeText(AddGrades.this, "Enter course number", Toast.LENGTH_SHORT).show();
                return;
            }
            if (TextUtils.isEmpty(courseHours.getText().toString())) {
                Toast.makeText(AddGrades.this, "Enter course hours", Toast.LENGTH_SHORT).show();
                return;
            }
            if (TextUtils.isEmpty(courseName.getText().toString())) {
                Toast.makeText(AddGrades.this, "Enter course name", Toast.LENGTH_SHORT).show();
                return;
            }

            double hours = Double.parseDouble(courseHours.getText().toString());
            long status = gradesDatabaseHelper.addCourseDetail(courseName.getText().toString(),
                    courseNum.getText().toString(),
                    hours, radioButton.getText().toString(), (selectedPoints * hours));

            Toast.makeText(AddGrades.this, "Added Records " + status, Toast.LENGTH_SHORT).show();
            finish();
        });
    }

    public void goToMainScreen() {
        Intent in = new Intent(this, MainActivity.class);
        startActivity(in);
    }
}