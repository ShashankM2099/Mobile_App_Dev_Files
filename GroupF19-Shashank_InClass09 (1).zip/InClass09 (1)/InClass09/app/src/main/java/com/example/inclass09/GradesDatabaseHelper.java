package com.example.inclass09;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;

public class GradesDatabaseHelper extends SQLiteOpenHelper {
    private static final int DATABASE_VERSION = 1;
    public static String TABLE_COURSES = "courses";

    private static final String KEY_ID = "id";
    private static final String KEY_NUMBER = "number";
    private static final String KEY_NAME = "name";
    private static final String KEY_HOURS = "hours";
    private static final String KEY_GRADE = "grade";
    private static final String KEY_POINTS = "points";
    private static final String CREATE_TABLE_COURSES = "CREATE TABLE "
            + TABLE_COURSES + "(" + KEY_ID
            + " INTEGER PRIMARY KEY AUTOINCREMENT," +
            KEY_NUMBER + " TEXT NOT NULL, " +
            KEY_NAME + " TEXT NOT NULL, " +
            KEY_HOURS + " DOUBLE NOT NULL, " +
            KEY_POINTS + " DOUBLE NOT NULL, " +
            KEY_GRADE + " VARCHAR " +
            "); ";
    public static String DATABASE_NAME = "Grades";

    public GradesDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);

        Log.d("table", CREATE_TABLE_COURSES);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_COURSES);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS '" + TABLE_COURSES + "'");
        onCreate(db);
    }

    public long addCourseDetail(String name, String number, double hours, String grade, double selectedPoints) {
        SQLiteDatabase db = this.getWritableDatabase();
        // Creating content values
        ContentValues values = new ContentValues();
        values.put(KEY_NAME, name);
        values.put(KEY_NUMBER, number);
        values.put(KEY_HOURS, hours);
        values.put(KEY_GRADE, grade);
        values.put(KEY_POINTS, selectedPoints);
        //insert row in table
        long insert = db.insert(TABLE_COURSES, null, values);

        return insert;
    }

    public ArrayList<CoursesModel> getAllCourses() {
        ArrayList<CoursesModel> coursesModelArrayList = new ArrayList<>();

        String selectQuery = "SELECT  * FROM " + TABLE_COURSES;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery(selectQuery, null);
        // looping through all rows and adding to list
        if (c.moveToFirst()) {
            do {
                CoursesModel coursesModel = new CoursesModel(c.getInt(c.getColumnIndex(KEY_ID)), c.getString(c.getColumnIndex(KEY_NAME)), c.getString(c.getColumnIndex(KEY_NUMBER)),
                        c.getString(c.getColumnIndex(KEY_GRADE)), c.getDouble(c.getColumnIndex(KEY_HOURS)),  c.getDouble(c.getColumnIndex(KEY_POINTS)));
                // adding to list
                coursesModelArrayList.add(coursesModel);
            } while (c.moveToNext());
        }
        return coursesModelArrayList;
    }

    public double getSumOfHours() {
       double totalHours = 0.0;

        String selectQuery = "SELECT  SUM(" + KEY_HOURS + ") as TotalHours FROM " + TABLE_COURSES;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery(selectQuery, null);
        if (c.moveToFirst()) {
            do {
                totalHours = c.getDouble(c.getColumnIndex("TotalHours"));
             return totalHours;
            } while (c.moveToNext());
        }
        return totalHours;
    }

    public double getSumOfPoints() {
        double totalHours = 0.0;

        String selectQuery = "SELECT  SUM(" + KEY_POINTS + ") as TotalPoints FROM " + TABLE_COURSES;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery(selectQuery, null);
        if (c.moveToFirst()) {
            do {
                totalHours = c.getDouble(c.getColumnIndex("TotalPoints"));
                return totalHours;
            } while (c.moveToNext());
        }
        return totalHours;
    }

    public void deleteCourse(int id) {
        // delete row in table based on id
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_COURSES, KEY_ID + " = ?",
                new String[]{String.valueOf(id)});
    }
}
