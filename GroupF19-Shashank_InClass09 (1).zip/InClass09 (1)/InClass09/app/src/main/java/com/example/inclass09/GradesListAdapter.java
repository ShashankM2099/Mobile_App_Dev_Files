package com.example.inclass09;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.inclass09.databinding.GradesListItemBinding;

import java.util.ArrayList;

public class GradesListAdapter extends RecyclerView.Adapter<GradesListAdapter.ViewHolder> {
    ArrayList<CoursesModel> gradesArrayList;
    GradeDeleteListener gradeDeleteListener;

    public GradesListAdapter(ArrayList<CoursesModel> gradesArrayList, GradeDeleteListener gradeDeleteListener) {
        this.gradesArrayList = gradesArrayList;
        this.gradeDeleteListener = gradeDeleteListener;
    }

    @NonNull
    @Override
    public GradesListAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(GradesListItemBinding.inflate(LayoutInflater.from(parent.getContext()),
                parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull GradesListAdapter.ViewHolder holder, final int position) {
        CoursesModel coursesModel = gradesArrayList.get(position);
        holder.gradesListItemBinding.gradeText.setText(coursesModel.getGrade());
        holder.gradesListItemBinding.courseNumberText.setText(coursesModel.getNumber());
        holder.gradesListItemBinding.courseNameTxt.setText(coursesModel.getName());
        holder.gradesListItemBinding.courseHoursTxt.setText(String.valueOf(coursesModel.getHours()));
        holder.gradesListItemBinding.buttonDeleteGrade.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            }
        });
    }

    @Override
    public int getItemCount() {
        return gradesArrayList == null ? 0 :
                gradesArrayList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        private GradesListItemBinding gradesListItemBinding;

        public ViewHolder(GradesListItemBinding gradesListItemBinding) {
            super(gradesListItemBinding.getRoot());
            this.gradesListItemBinding = gradesListItemBinding;
        }
    }

    interface GradeDeleteListener {
        void onDeleteGradeClick(String id);
    }
}
