package com.example.inclass09;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

/*
* Shashank Mondrati
* Student ID: 801026182
 */
public class MainActivity extends AppCompatActivity {
    TextView gpaTxt, creditHoursTxt;
    GradesListAdapter gradesListAdapter;
    double totalHours = 0.0;
    double totalPoints = 0.0;
    double result = 0.0;
    private RecyclerView coursesRecyclerView;
    private GradesDatabaseHelper gradesDatabaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.setTitle("Grades");

        coursesRecyclerView = findViewById(R.id.coursesRecyclerView);
        creditHoursTxt = findViewById(R.id.creditHours);
        gpaTxt = findViewById(R.id.gpaTxt);

        gradesDatabaseHelper = new GradesDatabaseHelper(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        ArrayList<CoursesModel> allCourses = gradesDatabaseHelper.getAllCourses();
        totalHours = gradesDatabaseHelper.getSumOfHours();
        totalPoints = gradesDatabaseHelper.getSumOfPoints();

        result = Math.round(totalPoints / totalHours);

        gpaTxt.setText("GPA: " + totalPoints);
        creditHoursTxt.setText("Hours: " + totalHours);

        gradesListAdapter = new GradesListAdapter(allCourses, new GradesListAdapter.GradeDeleteListener() {

            @Override
            public void onDeleteGradeClick(String id) {

            }
        });

        coursesRecyclerView.setHasFixedSize(true);
        coursesRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        coursesRecyclerView.setAdapter(gradesListAdapter);
    }

    public void goToAddScreen() {
        Intent nextActivity = new Intent(this, AddGrades.class);
        startActivity(nextActivity);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_add) {
            goToAddScreen();
        }
        return super.onOptionsItemSelected(item);
    }
}