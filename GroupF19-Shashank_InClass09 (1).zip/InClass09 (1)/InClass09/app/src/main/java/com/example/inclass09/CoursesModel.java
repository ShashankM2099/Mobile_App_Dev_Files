package com.example.inclass09;

public class CoursesModel {
    private String name;
    private String number;
    private String grade;
    private double hours;
    private double points;
    private int id;

    public CoursesModel(int id, String name, String number, String grade, double hours, double points) {
        this.id = id;
        this.name = name;
        this.number = number;
        this.grade = grade;
        this.hours = hours;
        this.points = points;
    }

    public String getName() {
        return name;
    }

    public String getNumber() {
        return number;
    }

    public String getGrade() {
        return grade;
    }

    public double getHours() {
        return hours;
    }

    public int getId() {
        return id;
    }

    public double getPoints() {
        return points;
    }
}
