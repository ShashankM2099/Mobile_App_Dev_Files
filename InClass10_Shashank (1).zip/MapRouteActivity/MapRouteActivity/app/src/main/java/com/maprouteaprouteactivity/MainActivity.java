package com.maprouteaprouteactivity;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;

import androidx.fragment.app.FragmentActivity;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.maprouteaprouteactivity.model.Point;
import com.maprouteaprouteactivity.model.Trip;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends FragmentActivity implements OnMapReadyCallback {

    ArrayList<LatLng> mMarkerPoints;
    Trip tripObject;
    PolylineOptions lineOptions = new PolylineOptions();
    private GoogleMap mMap;
    private ArrayList<Marker> mRouteMarkerList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.acitivity_maps);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);

        mapFragment.getMapAsync(this);

        mMarkerPoints = new ArrayList<>();
    }

    public Trip loadJSONFromAsset() {
        String json = null;
        Trip projectsList = null;
        try {
            InputStream is = getAssets().open("trip.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");
            final ObjectMapper objectMapper = new ObjectMapper();
            projectsList = objectMapper.readValue(json, Trip.class);

        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return projectsList;
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        tripObject = loadJSONFromAsset();

        googleMap.setOnMapLoadedCallback(new GoogleMap.OnMapLoadedCallback() {
            @Override
            public void onMapLoaded() {
                boolean hasPoints = false;
                Double maxLat = null, minLat = null, minLon = null, maxLon = null;

                if (lineOptions != null && lineOptions.getPoints() != null) {
                    List<LatLng> pts = lineOptions.getPoints();
                    for (LatLng coordinate : pts) {
                        // Find out the maximum and minimum latitudes & longitudes
                        // Latitude
                        maxLat = maxLat != null ? Math.max(coordinate.latitude, maxLat) : coordinate.latitude;
                        minLat = minLat != null ? Math.min(coordinate.latitude, minLat) : coordinate.latitude;

                        // Longitude
                        maxLon = maxLon != null ? Math.max(coordinate.longitude, maxLon) : coordinate.longitude;
                        minLon = minLon != null ? Math.min(coordinate.longitude, minLon) : coordinate.longitude;

                        hasPoints = true;
                    }
                }

                if (hasPoints) {
                    LatLngBounds.Builder builder = new LatLngBounds.Builder();
                    builder.include(new LatLng(maxLat, maxLon));
                    builder.include(new LatLng(minLat, minLon));
                    mMap.moveCamera(CameraUpdateFactory.newLatLngBounds(builder.build(), 48));
                }
            }
        });
        mMap = googleMap;
        if (mMarkerPoints.size() > 1) {
            mMarkerPoints.clear();
            mMap.clear();
        }

        LatLng sourcelatLng = new LatLng(tripObject.getPoints().get(0).getLatitude(), tripObject.getPoints().get(0).getLongitude());
        LatLng destlatLng = new LatLng(tripObject.getPoints().get(tripObject.getPoints().size() - 1).getLatitude(),
                tripObject.getPoints().get(tripObject.getPoints().size() - 1).getLongitude());

        MarkerOptions options = new MarkerOptions();
        options.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED));
        options.position(sourcelatLng);

        MarkerOptions option1 = new MarkerOptions();
        option1.position(destlatLng);
        option1.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED));

        Marker startMarker = mMap.addMarker(options);
        Marker endMarker = mMap.addMarker(option1);

        mRouteMarkerList.add(startMarker);
        mRouteMarkerList.add(endMarker);

        // Adding all the points in the route to LineOptions
        lineOptions.width(8);
        lineOptions.color(Color.RED);
        lineOptions.geodesic(true);

        for (Point point : tripObject.getPoints()) {
            LatLng position = new LatLng(point.getLatitude(), point.getLongitude());
            lineOptions.add(position);
        }

        mMap.addPolyline(lineOptions);

    }
}