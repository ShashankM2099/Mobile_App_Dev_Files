package com.example.inclass04;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.inclass04.databinding.FragmentSignUpBinding;


public class SignUpFragment extends Fragment {
    FragmentSignUpBinding binding;
    SignUpFragmentListener mListener;


    public SignUpFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentSignUpBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        getActivity().setTitle("Register Account");


        binding.buttonCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mListener.cancelSignUp();
            }
        });


        binding.buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String fullname = binding.editTextFullname.getText().toString();
                String email = binding.editTextEmail.getText().toString();
                String password = binding.editTextPassword.getText().toString();

                if (fullname.isEmpty()) {
                    Toast.makeText(getActivity(), "Enter valid name !!", Toast.LENGTH_SHORT).show();
                } else if (email.isEmpty()) {
                    Toast.makeText(getActivity(), "Enter valid email !!", Toast.LENGTH_SHORT).show();
                } else if (password.isEmpty()) {
                    Toast.makeText(getActivity(), "Enter valid password !!", Toast.LENGTH_SHORT).show();
                } else {
                    DataServices.AccountRequestTask accountRequestTask = DataServices.register(fullname, email, password);
                    if (accountRequestTask.isSuccessful()) {
                        mListener.goToMainPage(new UserAccount(accountRequestTask.getAccount().getName(), accountRequestTask.getAccount().getEmail(), accountRequestTask.getAccount().getPassword()));
                    } else {
                        Toast.makeText(getActivity(), accountRequestTask.getErrorMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mListener = (SignUpFragmentListener) context;
    }

    interface SignUpFragmentListener {
        void cancelSignUp(); // when user clicks on cancel needs to take it to login page

        void goToMainPage(UserAccount userAccount); // when loggged in take it to main Page, wher they can update or logout
    }
}