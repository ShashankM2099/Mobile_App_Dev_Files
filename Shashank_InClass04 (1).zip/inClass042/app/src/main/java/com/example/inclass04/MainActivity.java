package com.example.inclass04;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements LoginFragment.LoginFragmentListener,
        SignUpFragment.SignUpFragmentListener,
        AccountFragment.AccountFragmentListener,
        UpdateAccountFragment.UpdateAccountFragmentListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportFragmentManager().beginTransaction()
                .add(R.id.rootView, new LoginFragment())
                .commit();
    }

    @Override
    public void createAccount() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, new SignUpFragment())
                .commit();
    }

    @Override
    public void loginSuccessfulGotoAccounts(UserAccount userAccount) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, AccountFragment.newInstance(userAccount))
                .commit();
    }

    @Override
    public void cancelSignUp() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, new LoginFragment())
                .commit();
    }

    @Override
    public void goToMainPage(UserAccount userAccount) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, AccountFragment.newInstance(userAccount))
                .commit();
    }

    @Override
    public void editProfile(UserAccount account) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, UpdateAccountFragment.newInstance(account))
                .commit();
    }

    @Override
    public void logOut() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, new LoginFragment())
                .commit();
    }

    @Override
    public void accountUpdated(UserAccount account) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, AccountFragment.newInstance(account))
                .commit();
    }

    @Override
    public void cancelProfileUpdate(UserAccount account) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, AccountFragment.newInstance(account))
                .commit();
    }
}