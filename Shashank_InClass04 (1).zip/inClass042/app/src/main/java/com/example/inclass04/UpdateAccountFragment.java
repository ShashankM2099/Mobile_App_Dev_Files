package com.example.inclass04;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.inclass04.databinding.FragmentUpdateAccountBinding;


public class UpdateAccountFragment extends Fragment {

    private static final String ARG_USER_ACCOUNT = "ARG_USER_ACCOUNT";
    FragmentUpdateAccountBinding binding;
    UserAccount userAccount;
    UpdateAccountFragmentListener mListener;

    public UpdateAccountFragment() {
        // Required empty public constructor
    }

    public static UpdateAccountFragment newInstance(UserAccount userAccount) {
        UpdateAccountFragment fragment = new UpdateAccountFragment();
        Bundle args = new Bundle();
        args.putSerializable(ARG_USER_ACCOUNT, userAccount);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        getActivity().setTitle("Update Account");

        if (getArguments() != null) {
            userAccount = (UserAccount) getArguments().getSerializable(ARG_USER_ACCOUNT);
        }

        binding.txtViewDispName.setText(userAccount.name);

        binding.buttonUpdateCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mListener.cancelProfileUpdate(userAccount);
            }
        });

        binding.updateAccountBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String fullname = binding.editTextPersonName.getText().toString();
                String password = binding.editTextTextPassword.getText().toString();

                if (fullname.isEmpty()) {
                    Toast.makeText(getActivity(), "Enter valid name !!", Toast.LENGTH_SHORT).show();
                }  else if (password.isEmpty()) {
                    Toast.makeText(getActivity(), "Enter valid password !!", Toast.LENGTH_SHORT).show();
                } else {
                    DataServices.AccountRequestTask accountRequestTask = DataServices.update(new DataServices.Account(userAccount.name, userAccount.email, userAccount.password), fullname, password);
                    if (accountRequestTask.isSuccessful()) {
                        mListener.accountUpdated(new UserAccount(accountRequestTask.getAccount().getName(), accountRequestTask.getAccount().getEmail(), accountRequestTask.getAccount().getPassword()));
                    } else {
                        Toast.makeText(getActivity(), accountRequestTask.getErrorMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentUpdateAccountBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mListener = (UpdateAccountFragmentListener) context;
    }

    interface UpdateAccountFragmentListener {
        void accountUpdated(UserAccount userAccount); // when user makes changes to name and password

        void cancelProfileUpdate(UserAccount account); // when user decides to not to make any changes & clicks on cancel Btn
    }
}