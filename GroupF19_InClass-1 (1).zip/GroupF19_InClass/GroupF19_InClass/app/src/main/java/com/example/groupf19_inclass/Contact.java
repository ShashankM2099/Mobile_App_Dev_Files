package com.example.groupf19_inclass;

import java.util.ArrayList;

public class Contact {
    public String status;
    public ArrayList<Contacts> contacts;

//    public Contact(String status, ArrayList<Contacts> contacts) {
//        this.status = status;
//        this.contacts = contacts;
//    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public ArrayList<Contacts> getContacts() {
        return contacts;
    }

    public void setContacts(ArrayList<Contacts> contacts) {
        this.contacts = contacts;
    }
}

