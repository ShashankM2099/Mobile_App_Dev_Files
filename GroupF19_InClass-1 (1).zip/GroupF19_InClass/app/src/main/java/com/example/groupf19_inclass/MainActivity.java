package com.example.groupf19_inclass;

import androidx.appcompat.app.AppCompatActivity;

import android.icu.text.IDNA;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;


import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.Response;
import com.squareup.okhttp.ResponseBody;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.*;

import java.io.IOException;

public class MainActivity extends AppCompatActivity {
    Button b1;
    ListView lv;
    TextView txtV;
    //spublic RequestQueue rq;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        setContentView(R.layout.activity_main);
        lv = findViewById(R.id.listView);
        b1 = findViewById(R.id.button);
        txtV = findViewById(R.id.txt_view);


        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //jsonParse();
                getJsonContacts();
                //b1.setEnabled(false);
            }
        });

    }

    public void getJsonContacts() {
        String url = "https://www.theappsdr.com/contacts/json";
        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
                .url(url)
                .build();
        try {
            Response response = client.newCall(request).execute();
            String arr = null;
            arr = response.body().string();
            JSONObject obj = new JSONObject(arr);
          

            JSONArray array = obj.getJSONArray("contacts");
            String[] listItem = new String[array.length()];
            for (int i = 0; i < array.length(); i++) {
                JSONObject contacts = array.getJSONObject(i);
                //String cid = contacts.getString("Cid");
                String name = contacts.getString("Name");
                listItem[i] = name;
                //String email = contacts.getString("Email");
                //String phone = contacts.getString("Phone");
                //String phoneType = contacts.getString("PhoneType");
                //String result = String.valueOf(cid) + "\n" + name + "\n" + email + " \n" + phone + " \n " + phoneType;
                ;

            }
            final ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                    R.layout.list_view, R.id.textView, listItem);
            lv.setAdapter(adapter);
            lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                    // TODO Auto-generated method stub
//                    String value=adapter.getItem(position);
//                    Toast.makeText(getApplicationContext(),value,Toast.LENGTH_SHORT).show();

                }
            });
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }


    }
}