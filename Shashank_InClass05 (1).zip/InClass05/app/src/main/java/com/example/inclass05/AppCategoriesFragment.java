package com.example.inclass05;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.inclass05.databinding.FragmentAppCategoriesBinding;

import java.util.ArrayList;


public class AppCategoriesFragment extends Fragment {

    FragmentAppCategoriesBinding fragmentAppCategoriesBinding;
    AppCategoriesFragmentListener mListener;
    CategoriesListAdapter categoriesListAdapter;

    public AppCategoriesFragment() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        fragmentAppCategoriesBinding = FragmentAppCategoriesBinding.inflate(inflater, container, false);
        return fragmentAppCategoriesBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        getActivity().setTitle("App Categories");

        ArrayList<String> appCategories = DataServices.getAppCategories();

        categoriesListAdapter = new CategoriesListAdapter(appCategories, new CategoriesListAdapter.CategorySelectedListener() {
            @Override
            public void onCategorySelected(String category) {
                mListener.categorySelected(category);
            }
        });

        fragmentAppCategoriesBinding.categoriesRecyclerView.setHasFixedSize(true);
        fragmentAppCategoriesBinding.categoriesRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        fragmentAppCategoriesBinding.categoriesRecyclerView.setAdapter(categoriesListAdapter);
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mListener = (AppCategoriesFragmentListener) context;
    }


    interface AppCategoriesFragmentListener {
        void categorySelected(String category);
    }
}