package com.example.inclass05;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.inclass05.databinding.CategoryListItemBinding;

import java.util.ArrayList;

public class CategoriesListAdapter extends RecyclerView.Adapter<CategoriesListAdapter.ViewHolder> {
    ArrayList<String> categoryArrayList;
    CategorySelectedListener categorySelectedListener;

    public CategoriesListAdapter(ArrayList<String> categoryArrayList, CategorySelectedListener categorySelectedListener) {
        this.categoryArrayList = categoryArrayList;
        this.categorySelectedListener = categorySelectedListener;
    }

    @NonNull
    @Override
    public CategoriesListAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(CategoryListItemBinding.inflate(LayoutInflater.from(parent.getContext()),
                parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull CategoriesListAdapter.ViewHolder holder, final int position) {
        holder.categoryListItemBinding.categoryText.setText(categoryArrayList.get(position));
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                categorySelectedListener.onCategorySelected(categoryArrayList.get(position));
            }
        });
    }

    @Override
    public int getItemCount() {
        return categoryArrayList == null ? 0 :
                categoryArrayList.size();
    }

    interface CategorySelectedListener {
        void onCategorySelected(String category);
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        private final CategoryListItemBinding categoryListItemBinding;

        public ViewHolder(CategoryListItemBinding categoryListItemBinding) {
            super(categoryListItemBinding.getRoot());
            this.categoryListItemBinding = categoryListItemBinding;
        }
    }
}
