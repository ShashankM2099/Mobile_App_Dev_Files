package com.example.inclass05;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.inclass05.databinding.FragmentAppsListBinding;

import java.util.ArrayList;


public class AppsListFragment extends Fragment {
    private static final String ARG_APP_CATEGORY = "ARG_APP_CATEGORY";

    FragmentAppsListBinding fragmentAppsListBinding;
    AppsListFragmentListener mListener;
    AppsListAdapter appsListAdapter;
    String category;

    public AppsListFragment() {
        // Required empty public constructor
    }

    public static AppsListFragment newInstance(String category) {
        AppsListFragment fragment = new AppsListFragment();
        Bundle args = new Bundle();
        args.putSerializable(ARG_APP_CATEGORY, category);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            category = (String) getArguments().getSerializable(ARG_APP_CATEGORY);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        fragmentAppsListBinding = FragmentAppsListBinding.inflate(inflater, container, false);
        return fragmentAppsListBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        getActivity().setTitle(category);

        ArrayList<DataServices.App> appsByCategory = DataServices.getAppsByCategory(category);

        appsListAdapter = new AppsListAdapter(appsByCategory, new AppsListAdapter.AppSelectedListener() {
            @Override
            public void onAppSelected(DataServices.App app) {
                mListener.onAppSelected(app);
            }
        });

        fragmentAppsListBinding.appsRecyclerView.setHasFixedSize(true);
        fragmentAppsListBinding.appsRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        fragmentAppsListBinding.appsRecyclerView.setAdapter(appsListAdapter);
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mListener = (AppsListFragmentListener) context;
    }


    interface AppsListFragmentListener {
        void onAppSelected(DataServices.App app);
    }
}