package com.example.inclass05;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.inclass05.databinding.GenersListItemBinding;

import java.util.ArrayList;

public class GenresListAdapter extends RecyclerView.Adapter<GenresListAdapter.ViewHolder> {
    ArrayList<String> genresList;

    public GenresListAdapter(ArrayList<String> genresList) {
        this.genresList = genresList;
    }

    @NonNull
    @Override
    public GenresListAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(GenersListItemBinding.inflate(LayoutInflater.from(parent.getContext()),
                parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull GenresListAdapter.ViewHolder holder, final int position) {
        holder.genersListItemBinding.categoryText.setText(genresList.get(position));
    }

    @Override
    public int getItemCount() {
        return genresList == null ? 0 :
                genresList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        private final GenersListItemBinding genersListItemBinding;

        public ViewHolder(GenersListItemBinding genersListItemBinding) {
            super(genersListItemBinding.getRoot());
            this.genersListItemBinding = genersListItemBinding;
        }
    }
}
