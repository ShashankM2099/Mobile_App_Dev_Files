package com.example.inclass05;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.inclass05.databinding.AppsListItemBinding;

import java.util.ArrayList;

public class AppsListAdapter extends RecyclerView.Adapter<AppsListAdapter.ViewHolder> {
    ArrayList<DataServices.App> appArrayList;
    AppSelectedListener appSelectedListener;

    public AppsListAdapter(ArrayList<DataServices.App> appArrayList, AppSelectedListener appSelectedListener) {
        this.appArrayList = appArrayList;
        this.appSelectedListener = appSelectedListener;
    }

    @NonNull
    @Override
    public AppsListAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(AppsListItemBinding.inflate(LayoutInflater.from(parent.getContext()),
                parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull AppsListAdapter.ViewHolder holder, final int position) {
        DataServices.App app = appArrayList.get(position);
        holder.appsListItemBinding.appNameTxt.setText(app.name);
        holder.appsListItemBinding.artistNameTxt.setText(app.artistName);
        holder.appsListItemBinding.releaseDateTxt.setText(app.releaseDate);
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                appSelectedListener.onAppSelected(app);
            }
        });
    }

    @Override
    public int getItemCount() {
        return appArrayList == null ? 0 :
                appArrayList.size();
    }

    interface AppSelectedListener {
        void onAppSelected(DataServices.App app);
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        private final AppsListItemBinding appsListItemBinding;

        public ViewHolder(AppsListItemBinding appsListItemBinding) {
            super(appsListItemBinding.getRoot());
            this.appsListItemBinding = appsListItemBinding;
        }
    }
}
