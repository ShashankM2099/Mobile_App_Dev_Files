package edu.uncc.midtermapp;
// SHASHANK MONDRATI
// STUDENT ID: 801026182
// EMAIL ID: SMONDRAT@UNCC.EDU
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements LoginFragment.LoginFragmentListener, SignUpFragment.SignUpFragmentListener, PostsListFragment.PostsListFragmentListener, CreatePostFragment.CreatePostFragmentListener {
    UserToken mUserToken;
    SharedPreferences sharedPref;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sharedPref = getSharedPreferences(
                getString(R.string.preference_file_key), Context.MODE_PRIVATE);

        if (TextUtils.isEmpty(sharedPref.getString("token", ""))) {
            getSupportFragmentManager().beginTransaction()
                    .add(R.id.rootView, new LoginFragment())
                    .commit();
        } else {
            String token = sharedPref.getString("token", "");
            String fullName = sharedPref.getString("fullname", "");
            String userId = sharedPref.getString("userId", "");
            mUserToken = new UserToken(token, fullName, userId);

            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.rootView, PostsListFragment.newInstance(mUserToken))
                    .commit();
        }

    }

    @Override
    public void createAccount() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, new SignUpFragment())
                .commit();
    }

    @Override
    public void loginSuccessfulGotoPosts(UserToken userToken) {
        mUserToken = userToken;
        saveUserInformation(mUserToken);
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, PostsListFragment.newInstance(mUserToken))
                .commit();
    }

    @Override
    public void cancelSignUp() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, new LoginFragment())
                .commit();
    }

    @Override
    public void registerSuccessfulGotoPosts(UserToken userToken) {
        mUserToken = userToken;
        saveUserInformation(mUserToken);
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, PostsListFragment.newInstance(mUserToken))
                .commit();
    }

    @Override
    public void logout() {
        mUserToken = null;
        clearUserInformation();
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, new LoginFragment())
                .commit();
    }

    @Override
    public void createPost() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, CreatePostFragment.newInstance(mUserToken))
                .commit();
    }

    @Override
    public void cancelPost() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, PostsListFragment.newInstance(mUserToken))
                .commit();
    }

    @Override
    public void postSubmittedSuccessfullyGotoPosts() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, PostsListFragment.newInstance(mUserToken))
                .commit();
    }

    private void saveUserInformation(UserToken userToken) {
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putString("token", userToken.token);
        editor.putString("fullname", userToken.fullname);
        editor.putString("userId", userToken.userId);
        editor.apply();
    }

    private void clearUserInformation() {
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.clear().apply();
    }
}