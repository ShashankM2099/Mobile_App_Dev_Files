package edu.uncc.midtermapp;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;

import edu.uncc.midtermapp.databinding.FragmentPostsListBinding;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class PostsListFragment extends Fragment {
    private static final String ARG_USER_TOKEN = "ARG_USER_TOKEN";
    UserToken mUserToken;
    OkHttpClient client = new OkHttpClient();
    PostsListAdapter postsListAdapter;
    FragmentPostsListBinding fragmentPostsListBinding;
    PostsListFragmentListener mListener;
    private int mCurrentPosition = 1;
    private int totalPagesCount = 1;
    private int pageSize = 1;

    public PostsListFragment() {
        // Required empty public constructor
    }

    public static PostsListFragment newInstance(UserToken userToken) {
        PostsListFragment fragment = new PostsListFragment();
        Bundle args = new Bundle();
        args.putSerializable(ARG_USER_TOKEN, userToken);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        fragmentPostsListBinding = FragmentPostsListBinding.inflate(inflater, container, false);
        fragmentPostsListBinding.welcomeMessageText.setText("Welcome " + mUserToken.getFullname());

        fragmentPostsListBinding.buttonLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mListener.logout();
            }
        });

        fragmentPostsListBinding.buttonCreatePost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mListener.createPost();
            }
        });
        return fragmentPostsListBinding.getRoot();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mUserToken = (UserToken) getArguments().getSerializable(ARG_USER_TOKEN);
            getPostsData(mCurrentPosition);
        }
    }

    private void deletePost(String postId) {
        RequestBody formBody = new FormBody.Builder()
                .add("post_id", postId)
                .build();

        Request request = new Request.Builder()
                .url("https://www.theappsdr.com/posts/delete")
                .post(formBody)
                .addHeader("Authorization", "BEARER " + mUserToken.token)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                if (getActivity() != null && !getActivity().isFinishing()) {
                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getActivity(), "Unable to delete post !!", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (response.isSuccessful()) {
                    String body = response.body().string();
                    try {
                        JSONObject json = new JSONObject(body);
                        String message = json.getString("message");
                        if (getActivity() != null && !getActivity().isFinishing()) {
                            getActivity().runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(getActivity(), message, Toast.LENGTH_SHORT).show();

                                    getPostsData(mCurrentPosition);
                                }
                            });
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                } else {
                    String body = response.body().string();
                    try {
                        JSONObject json = new JSONObject(body);
                        String message = json.getString("message");
                        if (getActivity() != null && !getActivity().isFinishing()) {
                            getActivity().runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(getActivity(), message, Toast.LENGTH_SHORT).show();
                                }
                            });
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
    }

    private void getPostsData(int pageNumber) {
        this.mCurrentPosition = pageNumber;
        Request request = new Request.Builder()
                .url("https://www.theappsdr.com/posts?page=" + pageNumber)
                .addHeader("Authorization", "BEARER " + mUserToken.token)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                if (getActivity() != null && !getActivity().isFinishing()) {
                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getActivity(), "Unable to get posts !!", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (response.isSuccessful()) {
                    String body = response.body().string();
                    try {
                        ArrayList<Post> modelListViewArrayList = new ArrayList<>();
                        JSONObject json = new JSONObject(body);
                        JSONArray dataArray = json.getJSONArray("posts");

                        for (int i = 0; i < dataArray.length(); i++) {

                            JSONObject postObject = dataArray.getJSONObject(i);
                            Post modelListView = new Post(postObject.getString("created_by_name"), postObject.getString("post_id"),
                                    postObject.getString("created_by_uid"), postObject.getString("post_text"), postObject.getString("created_at"));
                            modelListViewArrayList.add(modelListView);

                        }

                        int pageNumber = json.getInt("page");
                        pageSize = json.getInt("pageSize");
                        totalPagesCount = json.getInt("totalCount");
                        int pagesCount = Math.round(totalPagesCount / pageSize);

                        if (getActivity() != null && !getActivity().isFinishing()) {
                            getActivity().runOnUiThread(new Runnable() {
                                @Override
                                public void run() {

                                    fragmentPostsListBinding.postPageNumberText.setText("Showing Page " + pageNumber + " out of " + pagesCount);
                                    postsListAdapter = new PostsListAdapter(mUserToken.userId, modelListViewArrayList, new PostsListAdapter.PostDeleteListener() {
                                        @Override
                                        public void onDeletePostClick(String postId) {
                                            deletePost(postId);
                                        }
                                    });
                                    fragmentPostsListBinding.postRecyclerView.setHasFixedSize(true);
                                    fragmentPostsListBinding.postRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
                                    fragmentPostsListBinding.postRecyclerView.setAdapter(postsListAdapter);

                                    PostPagesAdapter postPagesAdapter = new PostPagesAdapter(pagesCount, new PostPagesAdapter.PageSelectedListener() {
                                        @Override
                                        public void onPageSelect(int position) {
                                            getPostsData(position);
                                        }
                                    });

                                    fragmentPostsListBinding.postPagesRecyclerView.setHasFixedSize(true);
                                    fragmentPostsListBinding.postPagesRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false));
                                    fragmentPostsListBinding.postPagesRecyclerView.setAdapter(postPagesAdapter);

                                }
                            });
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                        if (getActivity() != null && !getActivity().isFinishing()) {
                            getActivity().runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(getActivity(), "Unable to get posts !!", Toast.LENGTH_SHORT).show();
                                }
                            });
                        }
                    }
                } else {
                    String body = response.body().string();
                    try {
                        JSONObject json = new JSONObject(body);
                        String message = json.getString("message");
                        if (getActivity() != null && !getActivity().isFinishing()) {
                            getActivity().runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(getActivity(), message, Toast.LENGTH_SHORT).show();
                                }
                            });
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        getActivity().setTitle("Posts");
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mListener = (PostsListFragmentListener) context;
    }


    interface PostsListFragmentListener {
        void logout();
        void createPost();
    }
}