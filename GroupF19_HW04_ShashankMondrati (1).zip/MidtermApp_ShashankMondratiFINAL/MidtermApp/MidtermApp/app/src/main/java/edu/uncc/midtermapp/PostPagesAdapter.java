package edu.uncc.midtermapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import edu.uncc.midtermapp.databinding.PagesListItemBinding;

public class PostPagesAdapter extends RecyclerView.Adapter<PostPagesAdapter.ViewHolder> {
    PageSelectedListener pageSelectedListener;
    int pagesCount;
    public PostPagesAdapter(int pagesCount, PageSelectedListener pageSelectedListener) {
        this.pagesCount = pagesCount;
        this.pageSelectedListener = pageSelectedListener;
    }

    @NonNull
    @Override
    public PostPagesAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new PostPagesAdapter.ViewHolder(PagesListItemBinding.inflate(LayoutInflater.from(parent.getContext()),
                parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull PostPagesAdapter.ViewHolder holder, final int position) {
        final int positionToDisplay = position + 1;
        holder.pagesListItemBinding.postPageNumberText.setText(""+ positionToDisplay);
        holder.pagesListItemBinding.postPageNumberText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pageSelectedListener.onPageSelect(positionToDisplay);
            }
        });
    }

    @Override
    public int getItemCount() {
        return pagesCount;
    }

    interface PageSelectedListener {
        void onPageSelect(int position);
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        private PagesListItemBinding pagesListItemBinding;

        public ViewHolder(PagesListItemBinding pagesListItemBinding) {
            super(pagesListItemBinding.getRoot());
            this.pagesListItemBinding = pagesListItemBinding;
        }
    }
}
