package edu.uncc.midtermapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import edu.uncc.midtermapp.databinding.PostListItemBinding;

public class PostsListAdapter extends RecyclerView.Adapter<PostsListAdapter.ViewHolder> {
    ArrayList<Post> postArrayList;
    PostDeleteListener postDeleteListener;
    String currentUserId;

    public PostsListAdapter(String currentUserId, ArrayList<Post> postArrayList, PostDeleteListener postDeleteListener) {
        this.postArrayList = postArrayList;
        this.postDeleteListener = postDeleteListener;
        this.currentUserId = currentUserId;
    }

    @NonNull
    @Override
    public PostsListAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(PostListItemBinding.inflate(LayoutInflater.from(parent.getContext()),
                parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull PostsListAdapter.ViewHolder holder, final int position) {
        Post post = postArrayList.get(position);
        holder.postListItemBinding.postText.setText(post.getPostText());
        holder.postListItemBinding.postCreatedName.setText(post.getPostCreatedName());
        holder.postListItemBinding.postDate.setText(post.getPostCreatedAt());
        if (post.postCreatedByUid.equals(currentUserId)) {
            holder.postListItemBinding.buttonDeletePost.setVisibility(View.VISIBLE);
        } else {
            holder.postListItemBinding.buttonDeletePost.setVisibility(View.GONE);
        }
        holder.postListItemBinding.buttonDeletePost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                postDeleteListener.onDeletePostClick(post.postId);
            }
        });
    }

    @Override
    public int getItemCount() {
        return postArrayList == null ? 0 :
                postArrayList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        private PostListItemBinding postListItemBinding;

        public ViewHolder(PostListItemBinding postListItemBinding) {
            super(postListItemBinding.getRoot());
            this.postListItemBinding = postListItemBinding;
        }
    }

    interface PostDeleteListener {
        void onDeletePostClick(String postId);
    }
}
