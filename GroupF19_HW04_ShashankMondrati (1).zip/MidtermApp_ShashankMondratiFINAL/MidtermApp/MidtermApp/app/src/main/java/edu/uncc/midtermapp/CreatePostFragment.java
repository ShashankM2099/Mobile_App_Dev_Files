package edu.uncc.midtermapp;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import edu.uncc.midtermapp.databinding.FragmentCreatePostBinding;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class CreatePostFragment extends Fragment {

    private static final String ARG_USER_TOKEN = "ARG_USER_TOKEN";

    UserToken mUserToken;
    FragmentCreatePostBinding binding;
    CreatePostFragmentListener mListener;
    OkHttpClient client = new OkHttpClient();

    public static CreatePostFragment newInstance(UserToken userToken) {
        CreatePostFragment fragment = new CreatePostFragment();
        Bundle args = new Bundle();
        args.putSerializable(ARG_USER_TOKEN, userToken);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentCreatePostBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mUserToken = (UserToken) getArguments().getSerializable(ARG_USER_TOKEN);
        }
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        getActivity().setTitle("Create Post");

        binding.buttonCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mListener.cancelPost();
            }
        });
        binding.buttonSubmitPost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String postText = binding.editTextPost.getText().toString();

                if (postText.isEmpty()) {
                    Toast.makeText(getActivity(), "Please enter post !!", Toast.LENGTH_SHORT).show();
                } else {
                    RequestBody formBody = new FormBody.Builder()
                            .add("post_text", postText)
                            .build();

                    Request request = new Request.Builder()
                            .url("https://www.theappsdr.com/posts/create")
                            .addHeader("Authorization", "BEARER " + mUserToken.token)
                            .post(formBody)
                            .build();

                    client.newCall(request).enqueue(new Callback() {
                        @Override
                        public void onFailure(@NonNull Call call, @NonNull IOException e) {
                            if (getActivity() != null && !getActivity().isFinishing()) {
                                getActivity().runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        Toast.makeText(getActivity(), "Unable to submit post !!", Toast.LENGTH_SHORT).show();
                                    }
                                });
                            }
                        }

                        @Override
                        public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                            if (response.isSuccessful()) {
                                String body = response.body().string();
                                try {
                                    JSONObject json = new JSONObject(body);
                                    String message = json.getString("message");
                                    if (getActivity() != null && !getActivity().isFinishing()) {
                                        getActivity().runOnUiThread(new Runnable() {
                                            @Override
                                            public void run() {
                                                Toast.makeText(getActivity(), message, Toast.LENGTH_SHORT).show();
                                                mListener.postSubmittedSuccessfullyGotoPosts();
                                            }
                                        });
                                    }
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            } else {
                                String body = response.body().string();
                                try {
                                    JSONObject json = new JSONObject(body);
                                    String message = json.getString("message");
                                    if (getActivity() != null && !getActivity().isFinishing()) {
                                        getActivity().runOnUiThread(new Runnable() {
                                            @Override
                                            public void run() {
                                                Toast.makeText(getActivity(), message, Toast.LENGTH_SHORT).show();
                                            }
                                        });
                                    }
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }
                        }
                    });
                }
            }
        });
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mListener = (CreatePostFragmentListener) context;
    }

    interface CreatePostFragmentListener {
        void cancelPost();
        void postSubmittedSuccessfullyGotoPosts();
    }
}