package edu.uncc.midtermapp;
// SHASHANK MONDRATI
// STUDENT ID: 801026182
// EMAIL ID: SMONDRAT@UNCC.EDU
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements LoginFragment.LoginFragmentListener, SignUpFragment.SignUpFragmentListener, PostsListFragment.PostsListFragmentListener, CreatePostFragment.CreatePostFragmentListener {
    UserToken mUserToken;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportFragmentManager().beginTransaction()
                .add(R.id.rootView, new LoginFragment())
                .commit();
    }

    @Override
    public void createAccount() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, new SignUpFragment())
                .commit();
    }

    @Override
    public void loginSuccessfulGotoPosts(UserToken userToken) {
        mUserToken = userToken;
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, PostsListFragment.newInstance(mUserToken))
                .commit();
    }

    @Override
    public void cancelSignUp() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, new LoginFragment())
                .commit();
    }

    @Override
    public void registerSuccessfulGotoPosts(UserToken userToken) {
        mUserToken = userToken;
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, PostsListFragment.newInstance(mUserToken))
                .commit();
    }

    @Override
    public void logout() {
        mUserToken = null;
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, new LoginFragment())
                .commit();
    }

    @Override
    public void createPost() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, CreatePostFragment.newInstance(mUserToken))
                .commit();
    }

    @Override
    public void cancelPost() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, PostsListFragment.newInstance(mUserToken))
                .commit();
    }

    @Override
    public void postSubmittedSuccessfullyGotoPosts() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, PostsListFragment.newInstance(mUserToken))
                .commit();
    }
}