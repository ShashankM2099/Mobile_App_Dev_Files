package edu.uncc.midtermapp;

public class Post {
    String postCreatedName;
    String postId;
    String postCreatedByUid;
    String postText;
    String postCreatedAt;

    public Post(String postCreatedName, String postId, String postCreatedByUid, String postText, String postCreatedAt) {
        this.postCreatedName = postCreatedName;
        this.postId = postId;
        this.postCreatedByUid = postCreatedByUid;
        this.postText = postText;
        this.postCreatedAt = postCreatedAt;
    }

    public String getPostCreatedName() {
        return postCreatedName;
    }

    public void setPostCreatedName(String postCreatedName) {
        this.postCreatedName = postCreatedName;
    }

    public String getPostId() {
        return postId;
    }

    public void setPostId(String postId) {
        this.postId = postId;
    }

    public String getPostCreatedByUid() {
        return postCreatedByUid;
    }

    public void setPostCreatedByUid(String postCreatedByUid) {
        this.postCreatedByUid = postCreatedByUid;
    }

    public String getPostText() {
        return postText;
    }

    public void setPostText(String postText) {
        this.postText = postText;
    }

    public String getPostCreatedAt() {
        return postCreatedAt;
    }

    public void setPostCreatedAt(String postCreatedAt) {
        this.postCreatedAt = postCreatedAt;
    }
}
