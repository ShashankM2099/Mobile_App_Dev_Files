package com.example.inclass03;

import java.io.Serializable;

public class Profile implements Serializable {
    private String name;
    private String email;
    private String id;
    private String department;

    public Profile(String name, String email, String id, String department) {
        this.name = name;
        this.email = email;
        this.id = id;
        this.department = department;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getId() {
        return id;
    }

    public String getDepartment() {
        return department;
    }
}
