package com.example.inclass03;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    TextView dept;
    EditText name, email, id;
    Button departmentList, submit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.setTitle("Registration");
        departmentList = findViewById(R.id.depBtn);
        departmentList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in = new Intent(MainActivity.this, DepartmentsListActivity.class);
                startActivityForResult(in, 111);
            }
        });
        name = (EditText) findViewById(R.id.editTextTextPersonName);
        email = (EditText) findViewById(R.id.editTextEmail);
        id = (EditText) findViewById(R.id.editTextIdNum);
        String dep = getIntent().getStringExtra("depname");
        dept = (TextView) findViewById(R.id.departmentTxt);
        dept.setText(dep);


        findViewById(R.id.submitBtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (TextUtils.isEmpty(name.getText().toString()) || TextUtils.isEmpty(email.getText().toString()) || TextUtils.isEmpty(id.getText().toString())) {
                    Toast.makeText(getApplicationContext(), "Enter a field ", Toast.LENGTH_SHORT).show();
                } else {
                    Profile profile = new Profile(name.getText().toString(), email.getText().toString(), id.getText().toString(), dept.getText().toString());
                    Intent in = new Intent(MainActivity.this, ProfileActivity.class);
                    in.putExtra("profile", profile);
                    startActivity(in);

                }
            }
        });


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 111) {
            if (resultCode == Activity.RESULT_OK) {
                dept.setText(data.getStringExtra("department"));
            }
        }
    }
}