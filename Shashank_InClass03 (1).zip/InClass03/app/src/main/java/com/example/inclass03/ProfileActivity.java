package com.example.inclass03;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import java.io.Serializable;

public class ProfileActivity extends AppCompatActivity {
    TextView userName,userEmail,userId,userDepartment;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        this.setTitle("Profile");
        userName = findViewById(R.id.userName);
        userEmail = findViewById(R.id.userEmail);
        userId = findViewById(R.id.userId);
        userDepartment = findViewById(R.id.userDep);

        Intent intent = getIntent();
        Profile profile = (Profile) intent.getSerializableExtra("profile");
        userName.setText(profile.getName());
        userEmail.setText(profile.getEmail());
        userId.setText(profile.getId());
        userDepartment.setText(profile.getDepartment());
    }
}