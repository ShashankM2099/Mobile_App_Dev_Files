package com.example.inclass03;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class DepartmentsListActivity extends AppCompatActivity {
    Button cancel, select;
    RadioGroup radioGroup;
    RadioButton radioButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.department_list);
        cancel = findViewById(R.id.canBtn);
        this.setTitle("Department");
        radioGroup = findViewById(R.id.radiogroup);
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in = new Intent();
                setResult(Activity.RESULT_CANCELED, in);
                finish();
            }
        });

        findViewById(R.id.selectBtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int radioId = radioGroup.getCheckedRadioButtonId(); // finds the radio ID
                radioButton = findViewById(radioId);
                Intent in = new Intent();
                in.putExtra("department", radioButton.getText());
                setResult(Activity.RESULT_OK, in);
                finish();
            }
        });
    }
}