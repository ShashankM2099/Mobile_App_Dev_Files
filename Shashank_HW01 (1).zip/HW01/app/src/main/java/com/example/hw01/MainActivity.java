package com.example.hw01;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    SeekBar seekBar;
    RadioGroup tipRadioGroup;
    RadioGroup personsGroup;
    TextView progtxt;
    EditText enterPrice;
    TextView tip, totalBillTxt, totalPerson;
    RadioButton ten, fifteen, eighteen, custom; // radios for tips percentages
    RadioButton onePer, twoPer, threePer, fourPer; // radios for split-wise by persons
    double userPrice, actualBillValue;
    double netTip;
    double netTotal;
    double finTotal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        seekBar = findViewById(R.id.seekBar);
        progtxt = findViewById(R.id.progressTxt);
        setTitle("Tip Calculator");

        tipRadioGroup = (RadioGroup) findViewById(R.id.tipRadioGroup);
        personsGroup = (RadioGroup) findViewById(R.id.personsGroup);
        tip = (TextView) findViewById(R.id.setTip); // setting TIP
        totalBillTxt = (TextView) findViewById(R.id.totalPrice); // setting first total
        totalPerson = (TextView) findViewById(R.id.totalPerPrice); // setting up second totalPerson price
        // Setting up radio buttons for TIP
        ten = findViewById(R.id.tenPer);
        fifteen = findViewById(R.id.fifPer);
        eighteen = findViewById(R.id.eightPer);
        custom = findViewById(R.id.custPer);

        tipRadioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                String enteredTxt = enterPrice.getText().toString();
                if (!TextUtils.isEmpty(enteredTxt)) {
                    actualBillValue = Double.parseDouble(enteredTxt);
                    int checkedRadioButtonId = tipRadioGroup.getCheckedRadioButtonId();
                    RadioButton radioButton = tipRadioGroup.findViewById(checkedRadioButtonId);
                    if (checkedRadioButtonId == R.id.custPer) {

                    } else {

                        if (ten.isChecked()) { //tip 10%
                            netTip = actualBillValue * (0.1);
                        }
                        if (fifteen.isChecked()) { // tip 15%
                            //userPrice = Double.parseDouble(enterPrice.toString());
                            netTip = actualBillValue * (0.15);
                        }
                        if (eighteen.isChecked()) { // tip 18%
                            //userPrice = Double.parseDouble(enterPrice.toString());
                            netTip = actualBillValue * (0.18);
                        }

                        netTotal =  (actualBillValue + netTip);
                        tip.setText("" + netTip);
                        totalBillTxt.setText("" + (actualBillValue + netTip));

                        if (onePer.isChecked()) {
                            finTotal = netTotal;
                        } else if (twoPer.isChecked()) {
                            finTotal = netTotal / 2;
                        } else if (threePer.isChecked()) {
                            finTotal = netTotal / 3;
                        } else if (fourPer.isChecked()) {
                            finTotal = netTotal / 4;
                        }

                        totalPerson.setText(""+finTotal);
                    }
                }
            }
        });

        enterPrice = (EditText) findViewById(R.id.etBillTotal); // enter tip
        enterPrice.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                String enteredTxt = enterPrice.getText().toString();
                if (!TextUtils.isEmpty(enteredTxt)) {
                    actualBillValue = Double.parseDouble(enteredTxt);
                    int checkedRadioButtonId = tipRadioGroup.getCheckedRadioButtonId();
                    RadioButton radioButton = tipRadioGroup.findViewById(checkedRadioButtonId);
                    if (checkedRadioButtonId == R.id.custPer) {

                    } else {

                        if (ten.isChecked()) { //tip 10%
                            netTip = actualBillValue * (0.1);
                        }
                        if (fifteen.isChecked()) { // tip 15%
                            //userPrice = Double.parseDouble(enterPrice.toString());
                            netTip = actualBillValue * (0.15);
                        }
                        if (eighteen.isChecked()) { // tip 18%
                            //userPrice = Double.parseDouble(enterPrice.toString());
                            netTip = actualBillValue * (0.18);
                        }

                        netTotal =  (actualBillValue + netTip);
                        tip.setText("" + netTip);
                        totalBillTxt.setText("" + (actualBillValue + netTip));

                        if (onePer.isChecked()) {
                            finTotal = netTotal;
                        } else if (twoPer.isChecked()) {
                            finTotal = netTotal / 2;
                        } else if (threePer.isChecked()) {
                            finTotal = netTotal / 3;
                        } else if (fourPer.isChecked()) {
                            finTotal = netTotal / 4;
                        }

                        totalPerson.setText(""+finTotal);
                    }
                }
            }
        });


        if (custom.isChecked()) {
            seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                    progtxt.setText("" + i + "%");
                }

                @Override
                public void onStartTrackingTouch(SeekBar seekBar) {
                }

                @Override
                public void onStopTrackingTouch(SeekBar seekBar) {
                }
            });
            // userPrice = Double.parseDouble(enterPrice.toString());
            netTip = userPrice * (seekBar.getProgress());
        }


        //splitting the money by persons
        onePer = findViewById(R.id.onePer);
        twoPer = findViewById(R.id.twoPer);
        threePer = findViewById(R.id.threePer);
        fourPer = findViewById(R.id.fourPer);

        personsGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                if (ten.isChecked()) { //tip 10%
                    netTip = actualBillValue * (0.1);
                }
                if (fifteen.isChecked()) { // tip 15%
                    //userPrice = Double.parseDouble(enterPrice.toString());
                    netTip = actualBillValue * (0.15);
                }
                if (eighteen.isChecked()) { // tip 18%
                    //userPrice = Double.parseDouble(enterPrice.toString());
                    netTip = actualBillValue * (0.18);
                }

                netTotal =  (actualBillValue + netTip);
                tip.setText("" + netTip);
                totalBillTxt.setText("" + (actualBillValue + netTip));

                if (onePer.isChecked()) {
                    finTotal = netTotal;
                } else if (twoPer.isChecked()) {
                    finTotal = netTotal / 2;
                } else if (threePer.isChecked()) {
                    finTotal = netTotal / 3;
                } else if (fourPer.isChecked()) {
                    finTotal = netTotal / 4;
                }

                totalPerson.setText(""+finTotal);

            }
        });

        // CLear Button...on cmd should set the fields to empty
        findViewById(R.id.clearBtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this, "Cleared", Toast.LENGTH_SHORT).show();
                enterPrice.setText("");
                tip.setText("");
                totalBillTxt.setText("");
                totalPerson.setText("");
            }
        });
    }
}